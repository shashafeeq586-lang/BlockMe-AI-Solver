# BlockMe AI Solver

Android 8x8 block puzzle scanner and move executor.

## Build
Run the `Build BlockMe AI APK` GitHub Actions workflow (`workflow_dispatch`) or push to `main`. The debug APK is uploaded as the `BlockMe-AI-Debug-APK` artifact.

## Changes in this revision
- Calibrated board coordinates for the supplied 709x1536 game screenshot.
- Corrected piece tile-size estimate from 0.041 to 0.060 of screen width (about 42.5 px at 709 px width).
- Restricted solver to the pieces' detected orientation because this app has no implemented in-game rotation gesture; this prevents selecting a move the automation cannot execute.
- Improved scan status messages when the board or pieces are not detected.

Note: runtime detection and touch execution still need validation on the target phone/game. The code cannot guarantee a successful move until tested on-device.
